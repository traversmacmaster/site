# TimeField 0.15.1 — Windows Beta

Temporal Audio Processor · Travers MacMaster
Release package: October 10, 2026

TimeField records incoming audio into a four-bar field and reshapes it through
six playback heads, a field loop, and effects. Use it as an audio effect on a
track receiving sound; MIDI is optional.

## Package contents

- TimeField.vst3 — complete Windows 64-bit VST3 plugin folder.
- README.md — installation, quick start, features, and beta notes.
- Screenshots — PLAY, MODULATION, and MIX / FX workspace previews.
- TimeField-0.15.1-Beta-Windows-x64.zip — plugin and README only.

## Installation / replacing an earlier beta

1. Save your DAW project and close the DAW.
2. Keep a backup of the previous TimeField.vst3 and important beta projects.
3. Copy the entire TimeField.vst3 folder into:
   C:\Program Files\Common Files\VST3\
   Accept the Windows administrator prompt if required. Replace the previous
   TimeField.vst3 folder rather than installing another copy under a new name.
4. Reopen your DAW and rescan VST3 plugins if TimeField is not listed.
5. Insert TimeField as an audio effect. In Ableton Live, look under Plug-Ins / VST3.

The .vst3 is a folder containing the plugin binary and resources: do not copy
only its inner binary. Extract the ZIP before installing. This package is for
Windows x64 VST3 hosts; it does not include macOS, Linux, or a standalone app.

## Quick start

1. Start your DAW transport and send audio through the track.
2. On PLAY, choose Record Target A and allow audio to fill the waveform.
3. Hold/freeze the field to preserve it. Choose Beat or Bar snap for musical
   freeze/unfreeze timing; Immediate applies changes without quantization.
4. Enable playback and add steps to a head's sequencer lane. Adjust Position,
   Size / Lock, Speed, Tune, and Level. Use H1–H2, H3–H4, or H5–H6 to edit a pair.
5. Open MODULATION for the selected pair's two LFOs per head.
6. Open MIX / FX to balance Input Monitor, Heads, and Field Loop, then add master FX.

For isolated processed playback, lower or mute Input Monitor and any unwanted
Field Loop signal. If there is no sound, check transport, sequencer steps, head
levels, and mute/solo states. The waveform shows capture, loop, and head positions.

## Three workspaces

PLAY: recording, waveform, head controls, and the six-lane sequencer. The
sequencer is the final section. Details can be collapsed to reduce scrolling.

MODULATION: four LFO panels for the selected head pair. All twelve LFOs remain
available across the three pairs.

MIX / FX: the three audio layers, mute/solo, optional MIDI, and master processing.

Workspace switches preserve settings and keep the audio engine running. The
workspace and selected head pair save with plugin state. A fresh editor opens
at 1120 × 900; window resizing is supported, with scrolling at smaller heights.
Custom window-size restoration depends on the host.

## Main features

- Six heads with Repeat, Ping-pong, Scan, and Hold playback; reverse and choke groups.
- Independent traversal speed, coarse/fine pitch, level, and Slip. Slip nudges
  read position continuously and resets at each trigger.
- Size Lock: Free, 1/128, 1/64, 1/32, 1/16, 1/8, 1/4, 1/2, 3/4, and 1/1.
- Sequences of 1, 2, or 4 bars at 1/16 or 1/32 resolution, with bar pages,
  probability, accent, copy/paste, clearing, and undo.
- Two recordings, A and B. Record Target chooses which receives new input;
  PLAY A+B enables their equal-power blend. Head and sequence settings are shared.
- Manual recording or bar-aligned takes of 1, 2, or 4 bars.
- Per-head Stutter plus a separate Head FX stage: low-pass, high-pass, band-pass,
  saturation, or bitcrush. Stutter and Head FX can be combined.
- Master FX: saturation, bitcrush, delay, or reverb, sourced from Input, Heads,
  Field Loop, or All.
- Four Scenes for sound, sequence, FX, and blend settings, with Immediate,
  Beat, or Bar recall. Scenes preserve recorded material.

## LFO destinations

Each head's two independent LFOs offer Free or tempo-synced timing, waveform,
retrigger behavior, and signed depth. Available targets:

Position; Rate; Level; Slip; Size / Lock; Pitch; Cutoff; Fine; Playback Amount;
Resonance; Sat Drive; Sat Tone; Crush Bits; Crush Downsample; Stutter Division;
Stutter Repeats; Stutter Decay.

Effect targets require the corresponding Head FX or Stutter to be enabled.
Two LFOs targeting the same control add their offsets within its allowed range.
Size, playback counts, and Stutter choices latch on triggers to keep active
fragments stable. LFOs do not change global recording or master FX settings.

## What changed in 0.15.1

The interface now separates PLAY, MODULATION, and MIX / FX, retaining all six
heads and twelve LFOs. Audio processing caches parameter reads and removes
redundant sample, modulation, and display work. BLK shows the actual callback
size delivered to the plugin, which may differ from the driver's buffer setting.

Matched local heavy six-head tests used approximately 42–58% less processing
time at 256/64 samples than 0.15.0, with identical reference audio. These are
local test results, not a guarantee of the same CPU reduction in every DAW.

## Beta notes / compatibility

- Save a backup before testing older projects. Plugin identity and existing
  parameter IDs are retained. Expanded choice ranges can change the mapping of
  older normalized automation; verify automated Size Lock and LFO destinations.
- Gate/Mask and Audio Memories are no longer exposed. Legacy Gate/Mask migrates
  to Off; legacy Stutter remains supported. A/B recordings and Scenes remain.
- The field follows host tempo/meter up to a 48-second maximum. In meters other
  than 4/4, sequencer resolution divides each bar into 16 or 32 equal slots.
- Changing sequencer resolution reinterprets stored steps; it does not insert steps.
- A+B uses equal-power mixing. Identical recordings at the center blend can be
  about 3 dB louder; leave output headroom.
- Loop Start currently rounds to whole beats in the engine, while its control
  allows finer positioning. Fine loop placement needs further refinement.
- Host-specific CPU behavior and saved-project reopening remain beta test areas.

Validation included audio/session regression tests, VST3 pluginval strictness 5,
and a workspace audit: switching pages produced zero sample difference with
all six heads active. Tests do not replace listening and project-reopen checks
in your own DAW.

When reporting a problem, include your DAW version, sample rate, audio buffer
size, TimeField BLK value, active heads/effects/A+B, and steps to reproduce it.
