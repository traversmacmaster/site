# T-SYNC V0.1

Windows x64 local master transport. T-SYNC produces no audio and hosts no instruments. DEADBEAT and WAVE HORROR remain independent JUCE standalone applications.

## Build and use

Run `build.ps1` from this directory. Release executables are collected in `Release` alongside this guide. Launch all three executables. In each instrument's bottom panel enable **T-SYNC CONNECT**, choose **GROUP A**, and select **T-SYNC** clock mode. Select INTERNAL to return to the instrument's original transport. Connection loss stops external sequencing rather than silently starting a competing local clock. Connection and clock mode are independent controls; turning CONNECT off while T-SYNC is selected stops external sequencing.

Master PLAY starts at zero. STOP preserves patterns, patches, parameters and release tails. RESET returns to zero and keeps the current playing/stopped state. Transport and tempo edits take effect after a 150 ms scheduling lead. Tempo range is 30–300 BPM. One run is the selected 1/2/4/8 bars in 4/4. Four runs of four bars stop at PPQ 64, with no new trigger on that boundary. Infinite runs have no end marker. All active groups share this timeline; disabled groups stop sequencing. Rejoining an active group joins its current position. Independent group timelines are deferred.

The panel's 1–16 STEPS selector applies only to external sequencing, retaining the stored 16-step patterns. Different lengths cycle independently against the master PPQ. Local playback keeps the original pattern length.

## Protocol and timing

`Shared/TSyncProtocol.h` defines protocol 1, identity, shared region, clock states and atomic wire snapshots. `TSyncMaster.h` owns transport; `TSyncClient.h` implements the same connection and audio timing code in both devices. `TSyncPanel.h` is their reusable JUCE UI. The platform implementation uses a Windows session-local named memory mapping, `Local\Travers.TSync.v1`, and a single-master named mutex. No socket, network adapter or Internet connection is needed. The master mutex is never used by audio callbacks.

The region contains a 256-entry journal of timestamped clock transitions and 32 device slots. Clock entries contain serial, QPC effective timestamp, epoch, PPQ anchor, tempo, playing state, active group mask, run bars and run count, and a finite end PPQ. Every wire word is an aligned 64-bit Interlocked atomic. A sequence counter validates clock snapshots with at most three attempts; readers fail stopped if a snapshot is unavailable. Effective timestamps are published before transitions occur. Rapid pending edits coalesce into the pending entry at the same effective boundary, retaining the preceding active timeline.

QPC is the common monotonic clock across processes. PPQ is computed analytically from timestamp anchors, never from GUI timer ticks. Tempo edits anchor the new tempo to the old timeline's position at the effective timestamp. PLAY and RESET advance an epoch. End markers are evaluated in each audio callback at the sample boundary. Journal history reserves timestamped transitions for future message types; parameter recording and playback are not implemented.

Mapping setup, slot registration and heartbeats run outside audio callbacks. Once mapped, its address is stable until client destruction. The audio callback reads fixed shared-memory words with bounded atomic snapshots; it performs no mapping operation, socket call, wait or mutex acquisition for T-SYNC. A communication worker handles registry heartbeats every 25 ms; the master heartbeat runs every 10 ms. A missing master lease stops external sequencing within 500 ms; stale instrument entries disappear after one second and can be reclaimed after two seconds. Protocol mismatch reports ERROR. Client instance IDs distinguish duplicate device types. Device names support 63 UTF-8 bytes.

Each audio callback anchors a sample timeline to QPC. Small callback jitter is filtered by limiting phase correction to one sample per block. A suspension over 100 ms reanchors the clock. Sequencers use absolute PPQ with their existing subdivision/swing behavior, suppressing backward duplicate crossings. All T-SYNC-generated events use preallocated buffers. The instrument adapters process timeline positions sample by sample; future optimization can split blocks at journal transitions without changing the protocol.

### Practical timing limits

This version synchronizes sequencer generation to the shared system clock. It does not measure or compensate output-device latency, independent DAC clock skew, driver buffering, or acoustic arrival time. Different audio devices or buffer sizes can therefore produce an audible offset. A common shared WASAPI device/buffer configuration is preferable for the first test. Callback startup and a long scheduling interruption can join partway through a step; this version does not claim hardware word-clock or guaranteed sample-exact acoustic alignment. Scheduled changes allow ordinary callback buffers to see the same boundary. This implementation is Windows-only and supports 32 simultaneous clients.

## Integrating another instrument

1. Add `Shared` to the project's include path. Instantiate `TSyncClient` with `TSyncDeviceInfo{typeId, humanName, patternLength, subdivisionsPerQuarter}` as a processor member, before its editor is created. Type IDs 1 and 2 identify DEADBEAT and WAVE HORROR; assign another stable ID to the next device. The client owns a unique per-instance ID.
2. Call `client.prepare(sampleRate)` in audio preparation. At each external audio callback call `beginBlock(numSamples)`, then `sample(sampleOffset)` for authoritative PPQ, BPM, epoch and playing state. Pass these values to the existing sequencer; reset its transport on epoch changes. Release held sequencer notes when transport stops. Keep patch and DSP reset separate from transport reset.
3. Keep the original clock path when `usesMaster()` is false. Do not allow local PLAY/RESET or host transport to override external authority. Update `length` and `division` metadata as needed. `report()` publishes diagnostic audio callback observations; it is not the timing source.
4. Add `TSyncPanel{client}` to the editor. The panel controls connection, group, clock mode and external cycle length. It does not drive timing.

For V0.2, add a distinct versioned timestamped parameter-event stream carrying instance ID, stable parameter ID, value and master PPQ/QPC timestamp. The precise instrument integration point is after the parameter change is accepted by the processor's parameter model; enqueue it off the audio thread or into a bounded preallocated queue. Keep gesture recording separate from the clock journal. No such capture is present in V0.1.

## Verification

`TSyncTests` verifies the actual shared mapping protocol, finite endpoints, clients launched before master, two clients, rapid tempo changes, stop/reset, groups, modes and master loss/reconnect. `TSyncSequencerTests` exercises both real sequencer implementations at 137 BPM for four four-bar runs, with 16/13-step polymeter, plus twenty simulated minutes and tempo changes at 30/300 BPM. Existing instrument suites cover synthesis, presets and local sequencing. These are automated code tests, not evidence that the three GUI applications successfully ran together.

`TSyncProbe` reads audio-callback counters, trigger counts, PPQ, epochs and transport states from running standalone applications. Its command mode is solely an integration-test driver; the production master UI uses the same timestamped journal. `test-integration.ps1` launches the three real applications and writes evidence to `validation`. **The three-application test has not been executed successfully in this session: automatic execution policy blocked the launch command. V0.1 remains unproven until that test and output timing checks pass.** See `validation/RESULTS.md` for the exact verification status.
