TimeField 1.0 - WINDOWS x64 VST3

CONTENTS
TimeField.vst3 - complete VST3 plugin folder.
README.txt - installation and getting started.
SHA256SUMS.txt - checksums for the supplied plugin files and documentation.

INSTALL
1. Extract the ZIP to a normal folder.
2. Save your DAW project and close the DAW.
3. Copy the entire TimeField.vst3 folder to:
   C:\Program Files\Common Files\VST3\
   Windows may request administrator permission. When updating, replace the old
   plugin folder; do not nest a new plugin folder inside the old one.
4. Open your DAW and rescan VST3 plugins if needed.
5. Load TimeField from your DAW's plugin list. Do not double-click the VST3 to run it.

GETTING STARTED
TimeField is an audio effect. Load it on a track receiving sound and start your DAW transport. Choose recording field A and let the waveform fill. Hold the recording, enable head steps in the sequencer, and adjust POSITION, SIZE, SPEED and TUNE. PLAY contains recording and sequencing; MODULATION contains head LFOs; MIX / FX contains levels and master effects. MIDI is optional.

REQUIREMENTS
Windows x64 and a DAW supporting VST3 plugins. This package contains the VST3
plugin, not a standalone application. Start with a low monitoring volume.

IF THE PLUGIN DOES NOT APPEAR
Confirm the full plugin folder is installed, then rescan plugins in the DAW.
Use a 64-bit VST3 host.

RELEASE IDENTIFICATION
Download package version: 1.0.
Internal beta build version: 0.15.1.
This distribution label does not change the embedded plugin version or IDs.

FEEDBACK
hello@traversmacmaster.com
Include the plugin name, DAW/version, Windows version and what happened.
